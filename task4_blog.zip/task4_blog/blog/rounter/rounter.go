package rounter

import (
	"blog/controllers"
	"blog/middleware"
	"github.com/gin-gonic/gin"
)

func InitRounters(r *gin.Engine) {
	api := r.Group("api")
	api.Use(middleware.Auth(), middleware.Logger())
	InitUser(api)
	InitPost(api)
	InitComment(api)

	LoginAndregister := r.Group("")
	LoginAndregister.Use(middleware.Logger())
	InitLoginAndregister(LoginAndregister)

}

func InitUser(group *gin.RouterGroup) {
	user := group.Group("user")
	user.POST("GetUesrById", controllers.GetUesrById)
	user.POST("GetUesrByname", controllers.GetUesrByname)
	user.POST("GetUesrByemail", controllers.GetUesrByemail)
	user.POST("CreatUesr", controllers.CreatUesr)
	user.POST("UpdateUser", controllers.UpdateUser)
	user.POST("UpdateUserPassWord", controllers.UpdateUserPassWord)
	user.POST("DeleteUesr", controllers.DeleteUesr)
}
func InitPost(group *gin.RouterGroup) {
	post := group.Group("post")
	post.POST("GetPostById", controllers.GetPostById)
	post.POST("GetPostByuid", controllers.GetPostByuid)
	post.POST("CreatPost", controllers.CreatPost)
	post.POST("UpdatePost", controllers.UpdatePost)
	post.POST("DeletePost", controllers.DeletePost)
}
func InitComment(group *gin.RouterGroup) {
	comment := group.Group("comment")
	comment.POST("GetCommentById", controllers.GetCommentById)
	comment.POST("GetCommentByContenter", controllers.GetCommentByContenter)
	comment.POST("GetCommentByPid", controllers.GetCommentByPid)
	comment.POST("GetCommentByContenterAndUid", controllers.GetCommentByContenterAndUid)
	comment.POST("CreatComment", controllers.CreatComment)
	comment.POST("UpdateComment", controllers.UpdateComment)
	comment.POST("DeleteComment", controllers.DeleteComment)
}

func InitLoginAndregister(group *gin.RouterGroup) {
	group.POST("Login", controllers.Login)
	group.POST("register", controllers.CreatUesr)

}
