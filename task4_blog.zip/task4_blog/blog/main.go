package main

import (
	"blog/config"
	"blog/middleware"
	"blog/modle"
	"blog/rounter"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"gorm.io/gorm"
	"log"
)

func GenerateTestData(db *gorm.DB) error {
	uid1 := uuid.New()
	uid2 := uuid.New()
	uid3 := uuid.New()
	uid4 := uuid.New()
	uid5 := uuid.New()
	pid1 := uuid.New()
	pid2 := uuid.New()
	pid3 := uuid.New()
	pid4 := uuid.New()
	pid5 := uuid.New()
	cid1 := uuid.New()
	cid2 := uuid.New()
	cid3 := uuid.New()
	cid4 := uuid.New()
	cid5 := uuid.New()
	users := []modle.User{
		{ID: uid1, Name: "测试用户1", PassWord: "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92", Email: "test1@example.com"},
		{ID: uid2, Name: "测试用户2", PassWord: "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92", Email: "test2@example.com"},
		{ID: uid3, Name: "测试用户3", PassWord: "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92", Email: "test3@example.com"},
		{ID: uid4, Name: "测试用户4", PassWord: "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92", Email: "test4@example.com"},
		{ID: uid5, Name: "测试用户5", PassWord: "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92", Email: "test5@example.com"},
	}
	posts := []modle.Post{
		{ID: pid1, Title: "测试文章标题1", Uid: uid5, Content: "这是测试文章1的内容。"},
		{ID: pid2, Title: "测试文章标题2", Uid: uid1, Content: "这是测试文章2的内容。"},
		{ID: pid3, Title: "测试文章标题3", Uid: uid2, Content: "这是测试文章3的内容。"},
		{ID: pid4, Title: "测试文章标题4", Uid: uid3, Content: "这是测试文章4的内容。"},
		{ID: pid5, Title: "测试文章标题5", Uid: uid4, Content: "这是测试文章5的内容。"},
	}
	comments := []modle.Comment{
		{ID: cid1, Content: "测试评论内容1", Pid: pid3, Contenter: uid5},
		{ID: cid2, Content: "测试评论内容2", Pid: pid3, Contenter: uid4},
		{ID: cid3, Content: "测试评论内容3", Pid: pid1, Contenter: uid3},
		{ID: cid4, Content: "测试评论内容4", Pid: pid2, Contenter: uid2},
		{ID: cid5, Content: "测试评论内容5", Pid: pid4, Contenter: uid1},
	}
	result := db.Create(&users)
	if result.Error != nil {
		println(result.Error)
	}
	result2 := db.Create(&posts)
	if result2.Error != nil {
		println(result2.Error)
	}
	result3 := db.Create(&comments)
	if result.Error != nil {
		println(result3.Error)
	}

	return nil
}

func main() {
	config.InitDB()
	middleware.InitLogger()
	db := config.GetDB()
	//自动迁移（创建表）
	err := db.AutoMigrate(&modle.User{}, &modle.Post{}, &modle.Comment{})
	if err != nil {
		log.Fatal("自动迁移失败:", err)
	}
	fmt.Println("数据库连接成功并完成迁移!")

	//GenerateTestData(db)

	r := gin.Default()
	rounter.InitRounters(r)
	r.Run(":8080")
}
