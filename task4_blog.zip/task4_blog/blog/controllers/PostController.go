package controllers

import (
	"blog/modle"
	"blog/server"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

func GetPostById(c *gin.Context) {
	var post modle.Post
	err := c.ShouldBindJSON(&post)
	if err != nil {
		fmt.Println(err)
	}

	modlepost, _ := server.GetPostById(post.ID)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modlepost,
	})
}

func GetPostByuid(c *gin.Context) {
	var post modle.Post
	err := c.ShouldBindJSON(&post)
	if err != nil {
		fmt.Println(err)
	}
	modlepost, _ := server.GetPostByuid(post.Uid)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modlepost,
	})
}

func CreatPost(c *gin.Context) {
	var post modle.Post
	err := c.ShouldBindJSON(&post)
	if err != nil {
		fmt.Println(err)
	}
	post.ID = uuid.New()
	modlepost, _ := server.CreatPost(post)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modlepost,
	})
}

func UpdatePost(c *gin.Context) {
	var post modle.Post
	err := c.ShouldBindJSON(&post)
	if err != nil {
		fmt.Println(err)
	}
	modlepost, _ := server.UpdatePost(post)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modlepost,
	})
}
func DeletePost(c *gin.Context) {
	var post modle.Post
	err := c.ShouldBindJSON(&post)
	if err != nil {
		fmt.Println(err)
	}
	modlepost, _ := server.GetPostById(post.ID)
	if modlepost.ID != uuid.Nil {
		success, _ := server.DeletePost(modlepost)
		if success {
			c.JSON(200, gin.H{
				"Status": "200",
				"data":   success,
			})
		}
	}
}
