package controllers

import (
	"blog/modle"
	"blog/server"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

func GetCommentById(c *gin.Context) {
	var content modle.Comment
	err := c.ShouldBindJSON(&content)
	if err != nil {
		fmt.Println(err)
	}

	modlecontent, _ := server.GetCommentById(content.ID)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modlecontent,
	})
}

func GetCommentByContenter(c *gin.Context) {
	var content modle.Comment
	err := c.ShouldBindJSON(&content)
	if err != nil {
		fmt.Println(err)
	}
	modlecomment, _ := server.GetCommentByContenter(content.Contenter)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modlecomment,
	})
}

func GetCommentByPid(c *gin.Context) {
	var content modle.Comment
	err := c.ShouldBindJSON(&content)
	if err != nil {
		fmt.Println(err)
	}
	modlecomment, _ := server.GetCommentByPid(content.Pid)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modlecomment,
	})
}
func GetCommentByContenterAndUid(c *gin.Context) {
	var content modle.Comment
	err := c.ShouldBindJSON(&content)
	if err != nil {
		fmt.Println(err)
	}
	modlecomment, _ := server.GetCommentByContenterAndUid(content.Contenter, content.Pid)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modlecomment,
	})
}
func CreatComment(c *gin.Context) {
	var comment modle.Comment
	err := c.ShouldBindJSON(&comment)
	if err != nil {
		fmt.Println(err)
	}
	comment.ID = uuid.New()
	modlecomment, _ := server.CreatComment(comment)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modlecomment,
	})
}

func UpdateComment(c *gin.Context) {
	var comment modle.Comment
	err := c.ShouldBindJSON(&comment)
	if err != nil {
		fmt.Println(err)
	}
	modleuser, _ := server.UpdateComment(comment)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modleuser,
	})
}
func DeleteComment(c *gin.Context) {
	var comment modle.Comment
	err := c.ShouldBindJSON(&comment)
	if err != nil {
		fmt.Println(err)
	}
	modlecomment, _ := server.GetCommentById(comment.ID)
	if modlecomment.ID != uuid.Nil {
		success, _ := server.DeleteComment(modlecomment)
		if success {
			c.JSON(200, gin.H{
				"Status": "200",
				"data":   success,
			})
		}
	}
}
