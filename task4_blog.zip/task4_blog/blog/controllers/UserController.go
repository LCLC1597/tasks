package controllers

import (
	"blog/modle"
	"blog/server"
	"blog/utils"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v4"
	"github.com/google/uuid"
	"net/http"
	"time"
)

func Login(c *gin.Context) {
	var user modle.User
	err := c.ShouldBindJSON(&user)
	if err != nil {
		fmt.Println(err)
	}
	modleuser, err := server.Login(user.Name, HashPasswordSHA256(user.PassWord))
	if err != nil {
		println(err)
	}
	if modleuser.ID == uuid.Nil {
		c.JSON(401, gin.H{
			"Status": "401",
			"data":   "用户名或密码错误",
		})
	} else {
		data := utils.Data{
			Name: modleuser.Name,
			RegisteredClaims: jwt.RegisteredClaims{
				ExpiresAt: jwt.NewNumericDate(time.Now().Add(time.Hour)),
				IssuedAt:  jwt.NewNumericDate(time.Now()),
				NotBefore: jwt.NewNumericDate(time.Now()),
			},
		}
		sign, err := utils.Sign(data)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{
				"error": err.Error(),
			})
			return
		}
		c.JSON(200, gin.H{
			"access_token": sign,
		})
	}

}

func GetUesrById(c *gin.Context) {
	var user modle.User
	err := c.ShouldBindJSON(&user)
	if err != nil {
		fmt.Println(err)
	}
	modleuser, err := server.GetUesrById(user.ID)
	if err != nil {
		println(err)
	}
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modleuser,
	})
}

func GetUesrByname(c *gin.Context) {
	var user modle.User
	err := c.ShouldBindJSON(&user)
	if err != nil {
		fmt.Println(err)
	}
	modleuser, _ := server.GetUesrByname(user.Name)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modleuser,
	})
}

func GetUesrByemail(c *gin.Context) {

	var user modle.User
	err := c.ShouldBindJSON(&user)
	if err != nil {
		fmt.Println(err)
	}
	modleuser, _ := server.GetUesrByemail(user.Email)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modleuser,
	})
}

func CreatUesr(c *gin.Context) {
	var user modle.User
	err := c.ShouldBindJSON(&user)
	if err != nil {
		fmt.Println(err)
	}
	user.ID = uuid.New()
	user.PassWord = HashPasswordSHA256(user.PassWord)
	modleuser, _ := server.CreatUser(user)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modleuser,
	})
}

func UpdateUser(c *gin.Context) {
	var user modle.User
	err := c.ShouldBindJSON(&user)
	if err != nil {
		fmt.Println(err)
	}
	modleuser, _ := server.UpdateUser(user)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modleuser,
	})
}

func UpdateUserPassWord(c *gin.Context) {
	var user modle.User
	err := c.ShouldBindJSON(&user)
	if err != nil {
		fmt.Println(err)
	}
	user.PassWord = HashPasswordSHA256(user.PassWord)
	modleuser, _ := server.UpdateUserPassWord(user)
	c.JSON(200, gin.H{
		"Status": "200",
		"data":   modleuser,
	})
}

func DeleteUesr(c *gin.Context) {
	var user modle.User
	err := c.ShouldBindJSON(&user)
	if err != nil {
		fmt.Println(err)
	}

	modleuser, _ := server.GetUesrById(user.ID)
	if modleuser.ID != uuid.Nil {
		success, _ := server.DeleteUser(modleuser)
		if success {
			c.JSON(200, gin.H{
				"Status": "200",
				"data":   success,
			})
		}
	}
}

func HashPasswordSHA256(password string) string {
	h := sha256.New()
	h.Write([]byte(password))
	hashBytes := h.Sum(nil)
	return hex.EncodeToString(hashBytes)
}
