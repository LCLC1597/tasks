package modle

import (
	"github.com/google/uuid"
	"time"
)

type User struct {
	ID        uuid.UUID `gorm:"primaryKey " json:"id"`
	Name      string    `gorm:"size:100,not null" json:"name"`
	PassWord  string    `gorm:"not null" json:"password"`
	Email     string    `gorm:"not null" json:"email"`
	CreatedAt time.Time `gorm:"autoCreateTime"`
	UpdatedAt time.Time `gorm:"autoUpdateTime"`
}
