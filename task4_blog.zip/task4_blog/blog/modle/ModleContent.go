package modle

import (
	"github.com/google/uuid"
	"time"
)

type Comment struct {
	ID        uuid.UUID `gorm:"primaryKey " json:"id"`
	Content   string    `gorm:"type:text;not null" json:"content"`
	Pid       uuid.UUID `gorm:"not null" json:"pid"`
	Contenter uuid.UUID `gorm:"not null" json:"contenter"`
	CreatedAt time.Time `gorm:"autoCreateTime"`
	UpdatedAt time.Time `gorm:"autoUpdateTime"`
}
