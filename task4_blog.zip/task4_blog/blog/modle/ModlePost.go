package modle

import (
	"github.com/google/uuid"
	"time"
)

type Post struct {
	ID        uuid.UUID `gorm:"primaryKey " json:"id"`
	Title     string    `gorm:"size:200,not null" json:"title"`
	Uid       uuid.UUID `gorm:"not null" json:"uid"`
	Content   string    `gorm:"type:text;not null" json:"content"`
	CreatedAt time.Time `gorm:"autoCreateTime"`
	UpdatedAt time.Time `gorm:"autoUpdateTime"`
}
