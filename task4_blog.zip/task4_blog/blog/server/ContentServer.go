package server

import (
	"blog/modle"
	"github.com/google/uuid"
)

func GetCommentById(id uuid.UUID) (modle.Comment, error) {
	var content modle.Comment
	getDB().Model(&modle.Comment{}).Where("id =?", id).Find(&content)
	return content, nil
}

func GetCommentByContenter(contenter uuid.UUID) ([]modle.Comment, error) {
	var contents []modle.Comment
	getDB().Model(&modle.Comment{}).Where("contenter =?", contenter).Find(&contents)
	return contents, nil
}

func GetCommentByPid(pid uuid.UUID) ([]modle.Comment, error) {
	var contents []modle.Comment
	getDB().Model(&modle.Comment{}).Where("pid =?", pid).Find(&contents)
	return contents, nil
}

func GetCommentByContenterAndUid(contenter, pid uuid.UUID) ([]modle.Comment, error) {
	var contents []modle.Comment
	getDB().Model(&modle.Comment{}).Where("contenter =? and pid=?", contenter, pid).Find(&contents)
	return contents, nil
}

func CreatComment(comment modle.Comment) (bool, error) {
	result := getDB().Create(&comment)
	return result.RowsAffected > 0, nil

}
func UpdateComment(comment modle.Comment) (bool, error) {

	result := getDB().Model(&modle.Comment{}).Where("id = ?", comment.ID).Updates(map[string]interface{}{
		"comment": comment.Content,
	})
	return result.RowsAffected > 0, nil
}

func DeleteComment(comment modle.Comment) (bool, error) {
	result := getDB().Delete(&comment)
	return result.RowsAffected > 0, nil
}
