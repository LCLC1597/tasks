package server

import (
	"blog/modle"
	"github.com/google/uuid"
)

func GetPostById(pid uuid.UUID) (modle.Post, error) {
	var post modle.Post
	getDB().Model(&modle.Post{}).Where("id =?", pid).Find(&post)
	return post, nil
}

func GetPostByuid(uid uuid.UUID) ([]modle.Post, error) {
	var posts []modle.Post
	getDB().Model(&modle.Post{}).Where("uid =?", uid).Find(&posts)
	return posts, nil
}

func CreatPost(post modle.Post) (bool, error) {
	result := getDB().Create(post)
	return result.RowsAffected > 0, nil

}
func UpdatePost(post modle.Post) (bool, error) {

	result := getDB().Model(&modle.Post{}).Where("id = ?", post.ID).Updates(map[string]interface{}{
		"title":   post.Title,
		"content": post.Content,
	})
	return result.RowsAffected > 0, nil
}

func DeletePost(post modle.Post) (bool, error) {
	result := getDB().Delete(&post)
	return result.RowsAffected > 0, nil
}
