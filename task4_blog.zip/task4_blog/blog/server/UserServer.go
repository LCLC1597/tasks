package server

import (
	"blog/modle"
	"github.com/google/uuid"
)

func GetUesrById(uid uuid.UUID) (modle.User, error) {
	var user modle.User
	getDB().Model(&modle.User{}).Where("id =?", uid).Find(&user)
	return user, nil
}

func GetUesrByname(name string) (*modle.User, error) {
	var user modle.User
	getDB().Model(&modle.User{}).Where("name =?", name).Find(&user)
	return &user, nil
}

func GetUesrByemail(email string) (*modle.User, error) {
	var user modle.User
	getDB().Model(&modle.User{}).Where("email =?", email).Find(&user)
	return &user, nil
}
func Login(name, password string) (*modle.User, error) {
	var user modle.User
	getDB().Model(&modle.User{}).Where("name =? and pass_word=?", name, password).Find(&user)
	return &user, nil
}
func CreatUser(user modle.User) (bool, error) {
	result := getDB().Create(&user)
	return result.RowsAffected > 0, nil

}
func UpdateUser(user modle.User) (bool, error) {

	result := getDB().Model(&modle.User{}).Where("id = ?", user.ID).Updates(map[string]interface{}{
		"name":  user.Name,
		"email": user.Email,
	})
	return result.RowsAffected > 0, nil
}

func UpdateUserPassWord(user modle.User) (bool, error) {

	result := getDB().Model(&modle.User{}).Where("id = ?", user.ID).Updates(map[string]interface{}{
		"password": user.PassWord,
	})
	return result.RowsAffected > 0, nil
}

func DeleteUser(user modle.User) (bool, error) {
	result := getDB().Delete(&user)
	return result.RowsAffected > 0, nil
}
