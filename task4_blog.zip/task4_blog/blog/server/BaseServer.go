package server

import (
	"blog/config"
	"gorm.io/gorm"
)

func getDB() *gorm.DB {
	return config.GetDB()
}
